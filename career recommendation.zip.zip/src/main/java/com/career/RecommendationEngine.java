package com.career;

/**
 * Recommendation logic that reads current session values and returns a human-readable
 * recommendation string. Also persists the recommendation to the database (by email).
 */
public class RecommendationEngine {

    /**
     * Build recommendation using Session fields and persist it into DB (by email).
     * @return recommendation text shown to user
     */
    public static String recommendCareerForSession() {
        // Defensive check
        String email = Session.currentUserEmail;
        if (email == null || email.trim().isEmpty()) {
            return "Please login before generating recommendations.";
        }

        // gather session values
        String s1 = Session.skill1 != null ? Session.skill1.toLowerCase() : "";
        String s2 = Session.skill2 != null ? Session.skill2.toLowerCase() : "";
        String i1 = Session.interest1 != null ? Session.interest1.toLowerCase() : "";
        String i2 = Session.interest2 != null ? Session.interest2.toLowerCase() : "";
        String grad = Session.graduation != null ? Session.graduation.trim() : "";
        String a10 = Session.academic10 != null ? Session.academic10.trim() : "";
        String a12 = Session.academic12 != null ? Session.academic12.trim() : "";

        boolean hasGraduated = !(grad.isEmpty() || grad.equalsIgnoreCase("n/a"));

        // helper to check skill/interest keywords
        java.util.function.Predicate<String> mentions = kw -> s1.contains(kw) || s2.contains(kw) || i1.contains(kw) || i2.contains(kw);

        StringBuilder rec = new StringBuilder();

        if (!hasGraduated) {
            // Recommend degree options (student hasn't completed graduation)
            // Use obvious signals: science keywords, commerce, arts, tech
            if (mentions.test("chem") || mentions.test("biology") || mentions.test("physics") || a12.matches("(?i).*science.*")) {
                rec.append("Recommended degrees (Science):\n")
                        .append("• B.Sc (Chemistry / Physics / Biology)\n")
                        .append("• B.Pharm / B.Sc. Biotechnology / Allied Health Diplomas\n")
                        .append("• Engineering (if inclined towards maths/physics): B.E / B.Tech\n");
            } else if (mentions.test("computer") || mentions.test("java") || mentions.test("python") || mentions.test("web")) {
                rec.append("Recommended degrees (Technology / Computing):\n")
                        .append("• B.E / B.Tech (Computer Science / IT)\n")
                        .append("• BCA / Diploma in Software Engineering\n");
            } else if (mentions.test("commerce") || a12.matches("(?i).*commerce.*") ) {
                rec.append("Recommended degrees (Commerce):\n")
                        .append("• B.Com / BBA\n")
                        .append("• CA / CMA (professional paths)\n");
            } else if (mentions.test("arts") || a12.matches("(?i).*arts.*")) {
                rec.append("Recommended degrees (Arts):\n")
                        .append("• B.A. (English / History / Social Sciences)\n")
                        .append("• B.Design / Interior Design (if creative)\n");
            } else {
                // fallback
                rec.append("Recommended degrees:\n")
                        .append("• B.Sc / B.E / B.Com / B.A depending on your interest area\n")
                        .append("Please complete the questionnaire for a more specific suggestion.\n");
            }

            // Save the degree-suggestion in DB (so it's not null)
            try {
                Database.updateRecommendedCareerByEmail(email, rec.toString());
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            return rec.toString();
        }

        // has graduated -> recommend job roles (based on degree / skills)
        if (mentions.test("computer") || grad.toLowerCase().contains("computer") || mentions.test("java") || mentions.test("python")) {
            rec.append("Recommended careers (Technology):\n")
                    .append("• Software Developer / Backend Developer\n")
                    .append("• Frontend / UI-UX Developer\n")
                    .append("• QA Engineer / DevOps (entry)\n");
        } else if (mentions.test("chem") || grad.toLowerCase().contains("chem")) {
            rec.append("Recommended careers (Chemistry):\n")
                    .append("• Chemist / Laboratory Analyst\n")
                    .append("• Research Scientist / Quality Control\n")
                    .append("• Pharmaceutical / R&D roles\n");
        } else if (mentions.test("biology") || grad.toLowerCase().contains("bio") || mentions.test("pharm")) {
            rec.append("Recommended careers (Biology / Healthcare):\n")
                    .append("• Biotechnologist / Lab Technician\n")
                    .append("• Medical Laboratory Technologist / Clinical Research\n")
                    .append("• Healthcare roles (nurse/technician) depending on specific qualification\n");
        } else if (mentions.test("commerce") || grad.toLowerCase().contains("commerce") || mentions.test("account")) {
            rec.append("Recommended careers (Commerce):\n")
                    .append("• Accountant / Tax Assistant\n")
                    .append("• Financial Analyst / Banking\n")
                    .append("• Audit / Accounts Executive\n");
        } else if (mentions.test("design") || mentions.test("ui") || mentions.test("ux") || mentions.test("art") || mentions.test("interior")) {
            rec.append("Recommended careers (Design / Creative):\n")
                    .append("• UI/UX Designer / Graphic Designer\n")
                    .append("• Interior Designer / Product Designer\n");
        } else {
            rec.append("Recommended careers:\n")
                    .append("• Explore roles that match your graduation field and skills.\n");
        }

        // Persist into DB
        try {
            Database.updateRecommendedCareerByEmail(email, rec.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return rec.toString();
    }
}
