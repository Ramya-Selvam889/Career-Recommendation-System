package com.career;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * DB helper. Keep your existing connect() method and add an update helper for recommended career.
 */
public class Database {

    private static Connection connection;
    private static final String URL = "jdbc:mysql://localhost:3306/career_database";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // <<-- set your MySQL root password if any

    public static Connection connect() {
        try {
            if (connection == null || connection.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    /**
     * Update the recommended_career column for the user with the given email.
     * This is used to persist both degree suggestions and final career recommendations.
     */
    public static boolean updateRecommendedCareerByEmail(String email, String recommendedCareer) {
        if (email == null || email.trim().isEmpty()) return false;
        String sql = "UPDATE users SET recommended_career = ? WHERE email = ?";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, recommendedCareer);
            ps.setString(2, email);
            int updated = ps.executeUpdate();
            return updated > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
