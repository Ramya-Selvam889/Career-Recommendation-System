package com.career;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.event.ActionEvent;

public class SkillsController {

    // Technical Skills
    @FXML private CheckBox javaSkill;
    @FXML private CheckBox pythonSkill;
    @FXML private CheckBox sqlSkill;
    @FXML private CheckBox webDevSkill;

    // Science Skills
    @FXML private CheckBox physicsSkill;
    @FXML private CheckBox chemistrySkill;
    @FXML private CheckBox biologySkill;
    @FXML private CheckBox mathSkill;
    @FXML private CheckBox researchSkill;

    @FXML
    private void goNext(ActionEvent e) {
        // pick primary skill in a priority order
        if (javaSkill.isSelected()) Session.skill1 = "Java";
        else if (pythonSkill.isSelected()) Session.skill1 = "Python";
        else if (sqlSkill.isSelected()) Session.skill1 = "SQL";
        else if (webDevSkill.isSelected()) Session.skill1 = "Web Development";
        else if (physicsSkill.isSelected()) Session.skill1 = "Physics";
        else if (chemistrySkill.isSelected()) Session.skill1 = "Chemistry";
        else if (biologySkill.isSelected()) Session.skill1 = "Biology";
        else if (mathSkill.isSelected()) Session.skill1 = "Mathematics";
        else if (researchSkill.isSelected()) Session.skill1 = "Research";
        else Session.skill1 = null;

        // second skill (simple)
        Session.skill2 = null;
        if (pythonSkill.isSelected() && !"Python".equals(Session.skill1)) Session.skill2 = "Python";
        else if (sqlSkill.isSelected() && !"SQL".equals(Session.skill1)) Session.skill2 = "SQL";
        else if (webDevSkill.isSelected() && !"Web Development".equals(Session.skill1)) Session.skill2 = "Web Development";
        else if (physicsSkill.isSelected() && !"Physics".equals(Session.skill1)) Session.skill2 = "Physics";
        else if (chemistrySkill.isSelected() && !"Chemistry".equals(Session.skill1)) Session.skill2 = "Chemistry";
        else if (biologySkill.isSelected() && !"Biology".equals(Session.skill1)) Session.skill2 = "Biology";
        else if (mathSkill.isSelected() && !"Mathematics".equals(Session.skill1)) Session.skill2 = "Mathematics";
        else if (researchSkill.isSelected() && !"Research".equals(Session.skill1)) Session.skill2 = "Research";

        SceneLoader.loadScene(e, "academic_form.fxml");
    }

    @FXML
    private void goBack(ActionEvent e) {
        SceneLoader.loadScene(e, "dashboard.fxml");
    }
}
