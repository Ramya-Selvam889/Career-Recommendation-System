package com.career;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {

    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private TextField visiblePasswordField;
    @FXML private Button togglePasswordBtn;

    private boolean passwordVisible = false;

    // Toggle eye button
    @FXML
    private void togglePassword(ActionEvent event) {
        if (passwordVisible) {
            // hide plain text, show PasswordField
            passwordField.setText(visiblePasswordField.getText());
            passwordField.setVisible(true);
            passwordField.setManaged(true);

            visiblePasswordField.setVisible(false);
            visiblePasswordField.setManaged(false);

            togglePasswordBtn.setText("👁");
            passwordVisible = false;
        } else {
            // show plain text, hide PasswordField
            visiblePasswordField.setText(passwordField.getText());
            visiblePasswordField.setVisible(true);
            visiblePasswordField.setManaged(true);

            passwordField.setVisible(false);
            passwordField.setManaged(false);

            togglePasswordBtn.setText("🙈");
            passwordVisible = true;
        }
    }

    // LOGIN button - checks DB and navigates to dashboard when OK
    @FXML
    private void handleLogin(ActionEvent event) {
        String email = emailField.getText().trim();
        String password = passwordVisible ? visiblePasswordField.getText().trim() : passwordField.getText().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert("Error", "Please enter email and password");
            return;
        }

        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE email=? AND password=?")) {

            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Session.currentUserEmail = email;
                // successful login -> go to dashboard
                SceneLoader.loadScene(event, "dashboard.fxml");
            } else {
                showAlert("Login Failed", "Invalid email or password");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Could not connect to database.");
        }
    }

    // REGISTER button - navigate to register page
    @FXML
    private void goRegister(ActionEvent event) {
        SceneLoader.loadScene(event, "register.fxml");
    }

    private void showAlert(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.show();
    }
}
