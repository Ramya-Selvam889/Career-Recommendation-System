package com.career;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.event.ActionEvent;

public class QuestionnaireController {

    @FXML private CheckBox q1;
    @FXML private CheckBox q2;
    @FXML private CheckBox q3;
    @FXML private CheckBox q4;
    @FXML private CheckBox q5;
    @FXML private CheckBox q6;
    @FXML private CheckBox q7;
    @FXML private CheckBox q8;
    @FXML private CheckBox q9;
    @FXML private CheckBox q10;

    @FXML
    private void goBack(ActionEvent e) {
        SceneLoader.loadScene(e, "academic_form.fxml");
    }

    @FXML
    private void submitQuestionnaire(ActionEvent e) {
        // map the checkboxes to interest tags
        // pick up to three interests
        Session.interest1 = q1.isSelected() ? "design" : (q4.isSelected() ? "technology" : null);
        if (q2.isSelected()) {
            if (Session.interest1 == null) Session.interest1 = "data";
            else Session.interest2 = "data";
        }
        if (q3.isSelected()) {
            if (Session.interest1 == null) Session.interest1 = "logic";
            else if (Session.interest2 == null) Session.interest2 = "logic";
            else Session.interest3 = "logic";
        }
        if (q5.isSelected()) { if (Session.interest2 == null) Session.interest2 = "science"; else if (Session.interest3 == null) Session.interest3 = "science"; }
        if (q6.isSelected()) { if (Session.interest2 == null) Session.interest2 = "mechanical"; else if (Session.interest3 == null) Session.interest3 = "mechanical"; }
        if (q7.isSelected()) { if (Session.interest2 == null) Session.interest2 = "data"; else if (Session.interest3 == null) Session.interest3 = "data"; }
        if (q8.isSelected()) { if (Session.interest2 == null) Session.interest2 = "fieldwork"; else if (Session.interest3 == null) Session.interest3 = "fieldwork"; }
        if (q9.isSelected()) { if (Session.interest2 == null) Session.interest2 = "medicine"; else if (Session.interest3 == null) Session.interest3 = "medicine"; }
        if (q10.isSelected()) { if (Session.interest2 == null) Session.interest2 = "arts"; else if (Session.interest3 == null) Session.interest3 = "arts"; }

        // fallback defaults
        if (Session.interest1 == null) Session.interest1 = "general";
        if (Session.interest2 == null) Session.interest2 = "general";

        SceneLoader.loadScene(e, "result.fxml");
    }
}
