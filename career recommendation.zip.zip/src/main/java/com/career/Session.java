package com.career;

public class Session {

    public static String currentUserEmail;

    public static String interest1;
    public static String interest2;
    public static String interest3;

    public static int skillLevel;
    public static String skill1;
    public static String skill2;

    public static String academic10;
    public static String academic12;
    public static String graduation;

    public static void clear() {
        currentUserEmail = null;
        interest1 = interest2 = interest3 = null;
        skillLevel = 0;
        skill1 = skill2 = null;
        academic10 = academic12 = graduation = null;
    }
}
