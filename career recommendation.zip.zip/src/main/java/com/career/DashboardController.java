package com.career;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

/**
 * DashboardController — handles the main dashboard button actions.
 * Each method uses SceneLoader.loadScene(...) to switch the content of the current window.
 */
public class DashboardController {

    @FXML
    private void openSkills(ActionEvent event) {
        SceneLoader.loadScene(event, "skills_form.fxml");
    }

    @FXML
    private void openAcademic(ActionEvent event) {
        SceneLoader.loadScene(event, "academic_form.fxml");
    }

    @FXML
    private void openQuestionnaire(ActionEvent event) {
        SceneLoader.loadScene(event, "questionnaire_form.fxml");
    }

    @FXML
    private void approveAndRecommend(ActionEvent event) {
        // This will show the result screen (which should compute & display the recommended career).
        SceneLoader.loadScene(event, "result.fxml");
    }

    @FXML
    private void logout(ActionEvent event) {
        // clear session and go back to login
        Session.clear();
        SceneLoader.loadScene(event, "login.fxml");
    }
}
