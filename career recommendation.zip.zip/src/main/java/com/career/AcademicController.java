package com.career;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;
import javafx.event.ActionEvent;

public class AcademicController {

    @FXML private TextField marks10;
    @FXML private TextField marks12;
    @FXML private TextField graduation;
    @FXML private CheckBox noGraduation;

    @FXML
    private void toggleGraduation(ActionEvent e) {
        if (noGraduation.isSelected()) {
            graduation.setDisable(true);
            graduation.clear();
        } else {
            graduation.setDisable(false);
        }
    }

    @FXML
    private void submitAcademic(ActionEvent e) {
        String tenth = marks10.getText().trim();
        String twelfth = marks12.getText().trim();
        String grad = noGraduation.isSelected() ? "N/A" : graduation.getText().trim();

        Session.academic10 = tenth.isEmpty() ? null : tenth;
        Session.academic12 = twelfth.isEmpty() ? null : twelfth;
        Session.graduation = grad == null ? null : grad;

        System.out.println("10th: " + Session.academic10 + " 12th: " + Session.academic12 + " graduation: " + Session.graduation);

        SceneLoader.loadScene(e, "questionnaire_form.fxml");
    }

    @FXML
    private void goBack(ActionEvent e) {
        SceneLoader.loadScene(e, "skills_form.fxml");
    }
}
