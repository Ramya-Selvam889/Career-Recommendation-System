package com.career;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ResultController {

    @FXML
    private Label careerLabel;

    @FXML
    public void initialize() {
        try {
            String result = RecommendationEngine.recommendCareerForSession();
            careerLabel.setText(result);
        } catch (Exception e) {
            e.printStackTrace();
            careerLabel.setText("Error generating recommendation.");
        }
    }

    @FXML
    private void backToDashboard(ActionEvent event) {
        try {
            SceneLoader.loadScene(event, "dashboard.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
